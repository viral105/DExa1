//
//  AppDelegate.h
//  DExa1
//
//  Created by Viral Narshana on 4/9/16.
//  Copyright (c) 2016 Viral Narshana. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

